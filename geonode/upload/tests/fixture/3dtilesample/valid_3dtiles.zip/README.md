Example provided by CensiumGS
https://github.com/CesiumGS/3d-tiles-samples